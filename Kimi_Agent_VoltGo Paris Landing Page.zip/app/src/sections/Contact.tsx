import { useRef, useLayoutEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Mail, Phone, Send, CheckCircle } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function Contact() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const pillsRef = useRef<HTMLDivElement>(null);
  const [submitted, setSubmitted] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Headline block
      gsap.fromTo(
        headlineRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 0.5,
          },
        }
      );

      // Form card
      gsap.fromTo(
        formRef.current,
        { x: '8vw', opacity: 0, scale: 0.98 },
        {
          x: 0,
          opacity: 1,
          scale: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
            end: 'top 50%',
            scrub: 0.5,
          },
        }
      );

      // Contact pills
      gsap.fromTo(
        pillsRef.current?.children || [],
        { y: 12, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          stagger: 0.1,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 70%',
            end: 'top 45%',
            scrub: 0.5,
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative w-full min-h-screen bg-voltgo-navy overflow-hidden z-[80] py-20 lg:py-0"
    >
      <div className="relative w-full h-full flex flex-col lg:flex-row items-center justify-center px-[6vw] py-10 lg:py-0">
        {/* Left Content */}
        <div
          ref={headlineRef}
          className="w-full lg:w-[40vw] lg:max-w-lg mb-10 lg:mb-0 lg:pr-8"
        >
          <h2
            className="font-display font-bold text-white mb-6"
            style={{ fontSize: 'clamp(2.25rem, 3.6vw, 3.25rem)', lineHeight: 1.05 }}
          >
            Ready to Partner?
          </h2>

          <p className="text-white/70 text-lg leading-relaxed mb-8">
            Join cafés and restaurants across Paris offering guests power on the
            go. No setup fees. One outlet. Small counter space.
          </p>

          {/* Contact Pills */}
          <div ref={pillsRef} className="flex flex-wrap gap-3">
            <a
              href="mailto:voltgoparis@gmail.com"
              className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/15 text-white px-5 py-3 rounded-full transition-colors"
            >
              <Mail className="w-4 h-4 text-voltgo-green" />
              <span className="text-sm">voltgoparis@gmail.com</span>
            </a>
            <a
              href="tel:+33652919766"
              className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/15 text-white px-5 py-3 rounded-full transition-colors"
            >
              <Phone className="w-4 h-4 text-voltgo-green" />
              <span className="text-sm">+33 6 52 91 97 66</span>
            </a>
          </div>
        </div>

        {/* Right Form Card */}
        <div
          ref={formRef}
          className="w-full lg:w-[42vw] lg:max-w-xl bg-voltgo-cloud rounded-[28px] p-8 lg:p-10"
        >
          {submitted ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="w-16 h-16 bg-voltgo-green/20 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="w-8 h-8 text-voltgo-green" />
              </div>
              <h3 className="font-display font-semibold text-2xl text-voltgo-navy mb-2">
                Message Sent!
              </h3>
              <p className="text-voltgo-slate">
                We'll get back to you within 24 hours.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-voltgo-navy font-medium">
                    Name
                  </Label>
                  <Input
                    id="name"
                    placeholder="Your name"
                    required
                    className="bg-white border-voltgo-navy/10 focus:border-voltgo-green focus:ring-voltgo-green/20 rounded-xl h-12"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="venue" className="text-voltgo-navy font-medium">
                    Venue
                  </Label>
                  <Input
                    id="venue"
                    placeholder="Restaurant/Café name"
                    required
                    className="bg-white border-voltgo-navy/10 focus:border-voltgo-green focus:ring-voltgo-green/20 rounded-xl h-12"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-voltgo-navy font-medium">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@venue.com"
                    required
                    className="bg-white border-voltgo-navy/10 focus:border-voltgo-green focus:ring-voltgo-green/20 rounded-xl h-12"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-voltgo-navy font-medium">
                    Phone
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+33 1 23 45 67 89"
                    className="bg-white border-voltgo-navy/10 focus:border-voltgo-green focus:ring-voltgo-green/20 rounded-xl h-12"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-voltgo-navy font-medium">
                  Message
                </Label>
                <Textarea
                  id="message"
                  placeholder="Tell us about your venue..."
                  rows={4}
                  className="bg-white border-voltgo-navy/10 focus:border-voltgo-green focus:ring-voltgo-green/20 rounded-xl resize-none"
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-voltgo-green hover:bg-voltgo-green/90 text-voltgo-navy font-semibold py-6 rounded-xl text-base transition-all duration-300 hover:scale-[1.02] hover:shadow-lg group"
              >
                Request a Setup
                <Send className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
