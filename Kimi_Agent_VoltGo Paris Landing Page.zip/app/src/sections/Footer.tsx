import { useRef, useLayoutEffect } from 'react';
import { Zap } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function Footer() {
  const footerRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const footer = footerRef.current;
    if (!footer) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { y: 18, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: footer,
            start: 'top 90%',
            end: 'top 70%',
            scrub: 0.5,
          },
        }
      );
    }, footer);

    return () => ctx.revert();
  }, []);

  return (
    <footer
      ref={footerRef}
      className="relative w-full bg-voltgo-navy py-16 z-[90]"
    >
      <div
        ref={contentRef}
        className="max-w-4xl mx-auto px-6 text-center"
      >
        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="relative w-10 h-10 flex items-center justify-center">
            <Zap className="w-7 h-7 text-voltgo-green fill-voltgo-green" />
          </div>
          <span className="font-display font-bold text-2xl tracking-tight text-white">
            VoltGo
          </span>
          <span className="font-display font-medium text-lg text-white/60">
            Paris
          </span>
        </div>

        {/* Tagline */}
        <p className="text-white/60 text-lg mb-8">Power On The Go</p>

        {/* Links */}
        <div className="flex items-center justify-center gap-8 mb-8">
          <a
            href="#"
            className="text-white/60 hover:text-voltgo-green transition-colors text-sm"
          >
            Privacy
          </a>
          <a
            href="#"
            className="text-white/60 hover:text-voltgo-green transition-colors text-sm"
          >
            Terms
          </a>
          <a
            href="#contact"
            className="text-white/60 hover:text-voltgo-green transition-colors text-sm"
          >
            Contact
          </a>
        </div>

        {/* Copyright */}
        <p className="text-white/40 text-sm">
          © 2026 VoltGo Paris. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
