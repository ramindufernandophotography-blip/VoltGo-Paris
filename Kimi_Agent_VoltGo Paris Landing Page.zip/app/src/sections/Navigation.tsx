import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Zap } from 'lucide-react';

export function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToContact = () => {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-voltgo-cloud/90 backdrop-blur-md py-4'
          : 'bg-transparent py-6'
      }`}
    >
      <div className="w-full px-6 lg:px-12 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div className="relative w-8 h-8 flex items-center justify-center">
            <Zap className="w-6 h-6 text-voltgo-green fill-voltgo-green" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight text-voltgo-navy">
            VoltGo
          </span>
          <span className="font-display font-medium text-sm text-voltgo-slate hidden sm:inline">
            Paris
          </span>
        </a>

        {/* CTA Button */}
        <Button
          onClick={scrollToContact}
          className="bg-voltgo-green hover:bg-voltgo-green/90 text-voltgo-navy font-semibold px-6 py-2.5 rounded-full transition-all duration-300 hover:scale-105 hover:shadow-lg"
        >
          Become a Partner
        </Button>
      </div>
    </nav>
  );
}
