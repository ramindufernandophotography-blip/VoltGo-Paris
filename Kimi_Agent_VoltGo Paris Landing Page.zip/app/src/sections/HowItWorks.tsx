import { useRef, useLayoutEffect } from 'react';
import { CreditCard, Battery, RotateCcw } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    number: '1',
    title: 'Tap',
    description: 'Guest taps a card to unlock a power bank in seconds.',
    image: '/step1_tap.jpg',
    icon: CreditCard,
  },
  {
    number: '2',
    title: 'Rent',
    description: 'Around €2/hour. They charge while they relax.',
    image: '/step2_rent.jpg',
    icon: Battery,
  },
  {
    number: '3',
    title: 'Return',
    description: 'Drop off at any station—no stress, no cables.',
    image: '/step3_return.jpg',
    icon: RotateCcw,
  },
];

export function HowItWorks() {
  const sectionRef = useRef<HTMLElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Label entrance
      scrollTl.fromTo(
        labelRef.current,
        { y: -20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      );

      // Card 1 entrance (from left)
      scrollTl.fromTo(
        cardsRef.current[0],
        { x: '-60vw', opacity: 0, rotate: -2 },
        { x: 0, opacity: 1, rotate: 0, ease: 'none' },
        0
      );

      // Card 2 entrance (from bottom)
      scrollTl.fromTo(
        cardsRef.current[1],
        { y: '60vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.05
      );

      // Card 3 entrance (from right)
      scrollTl.fromTo(
        cardsRef.current[2],
        { x: '60vw', opacity: 0, rotate: 2 },
        { x: 0, opacity: 1, rotate: 0, ease: 'none' },
        0.1
      );

      // SETTLE (30-70%): Hold position

      // EXIT (70-100%)
      scrollTl.fromTo(
        cardsRef.current[0],
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        cardsRef.current[1],
        { y: 0, opacity: 1 },
        { y: '-10vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        cardsRef.current[2],
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        labelRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="how-it-works"
      className="relative w-full h-screen bg-voltgo-cloud overflow-hidden z-20"
    >
      {/* Label */}
      <span
        ref={labelRef}
        className="absolute top-[10vh] left-1/2 -translate-x-1/2 font-mono text-xs tracking-[0.12em] uppercase text-voltgo-slate"
      >
        How It Works
      </span>

      {/* Cards Container */}
      <div className="absolute inset-0 flex items-center justify-center px-[6vw]">
        <div className="flex gap-[3vw] w-full max-w-7xl">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div
                key={step.number}
                ref={(el) => { cardsRef.current[index] = el; }}
                className="flex-1 bg-white rounded-[28px] overflow-hidden card-shadow flex flex-col"
                style={{ height: '56vh' }}
              >
                {/* Image */}
                <div className="relative h-[55%] overflow-hidden">
                  <img
                    src={step.image}
                    alt={step.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <Icon className="w-5 h-5 text-voltgo-navy" />
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 p-6 flex flex-col justify-center">
                  <div className="flex items-baseline gap-2 mb-3">
                    <span className="font-display font-bold text-3xl text-voltgo-green">
                      {step.number})
                    </span>
                    <h3 className="font-display font-semibold text-2xl text-voltgo-navy">
                      {step.title}
                    </h3>
                  </div>
                  <p className="text-voltgo-slate leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
