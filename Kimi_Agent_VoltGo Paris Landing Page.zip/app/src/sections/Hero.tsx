import { useEffect, useRef, useLayoutEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, ChevronDown } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  // Auto-play entrance animation on page load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power2.out' } });

      // Micro label
      tl.fromTo(
        labelRef.current,
        { y: 12, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.4 },
        0
      );

      // Headline (split by words)
      if (headlineRef.current) {
        const words = headlineRef.current.querySelectorAll('.word');
        tl.fromTo(
          words,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.05 },
          0.15
        );
      }

      // Subheadline
      tl.fromTo(
        subheadlineRef.current,
        { y: 18, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5 },
        0.55
      );

      // CTA row
      tl.fromTo(
        ctaRef.current,
        { y: 14, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.4 },
        0.75
      );

      // Image card
      tl.fromTo(
        imageRef.current,
        { x: '10vw', scale: 0.96, opacity: 0 },
        { x: 0, scale: 1, opacity: 1, duration: 0.85 },
        0.25
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back to top
            gsap.set([labelRef.current, subheadlineRef.current, ctaRef.current], {
              opacity: 1,
              x: 0,
            });
            if (headlineRef.current) {
              gsap.set(headlineRef.current.querySelectorAll('.word'), { opacity: 1, x: 0 });
            }
            gsap.set(imageRef.current, { opacity: 1, x: 0, scale: 1 });
          },
        },
      });

      // ENTRANCE (0-30%): Hold the load end state (no additional entrance)
      // SETTLE (30-70%): Static composition

      // EXIT (70-100%)
      scrollTl.fromTo(
        [labelRef.current, headlineRef.current, subheadlineRef.current, ctaRef.current],
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        imageRef.current,
        { x: 0, scale: 1, opacity: 1 },
        { x: '18vw', scale: 0.98, opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToHowItWorks = () => {
    const howItWorksSection = document.getElementById('how-it-works');
    if (howItWorksSection) {
      howItWorksSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContact = () => {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen bg-voltgo-cloud overflow-hidden z-10"
    >
      {/* Content Container */}
      <div className="relative w-full h-full flex items-center">
        {/* Left Content */}
        <div className="absolute left-[6vw] top-[18vh] w-[42vw] max-w-xl">
          {/* Micro Label */}
          <span
            ref={labelRef}
            className="font-mono text-xs tracking-[0.12em] uppercase text-voltgo-slate mb-6 block"
          >
            VoltGo Paris
          </span>

          {/* Headline */}
          <h1
            ref={headlineRef}
            className="font-display font-bold text-voltgo-navy mb-6"
            style={{ fontSize: 'clamp(2.75rem, 5vw, 4.5rem)', lineHeight: 0.95 }}
          >
            <span className="word inline-block">Power</span>{' '}
            <span className="word inline-block">On</span>{' '}
            <span className="word inline-block">The</span>{' '}
            <span className="word inline-block">Go</span>
          </h1>

          {/* Subheadline */}
          <p
            ref={subheadlineRef}
            className="text-voltgo-slate text-lg leading-relaxed mb-8 max-w-md"
          >
            A sleek charging station for restaurants, cafés, and bars—so guests
            stay longer and come back often.
          </p>

          {/* CTA Buttons */}
          <div ref={ctaRef} className="flex flex-wrap gap-4">
            <Button
              onClick={scrollToContact}
              className="bg-voltgo-green hover:bg-voltgo-green/90 text-voltgo-navy font-semibold px-8 py-6 rounded-full text-base transition-all duration-300 hover:scale-105 hover:shadow-xl group"
            >
              Become a Partner
              <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Button>
            <Button
              onClick={scrollToHowItWorks}
              variant="outline"
              className="border-voltgo-navy/20 text-voltgo-navy hover:bg-voltgo-navy/5 px-8 py-6 rounded-full text-base transition-all duration-300"
            >
              How it Works
              <ChevronDown className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Right Image Card */}
        <div
          ref={imageRef}
          className="absolute right-[6vw] top-[14vh] w-[40vw] h-[72vh] rounded-[28px] overflow-hidden card-shadow"
        >
          <img
            src="/hero_station.jpg"
            alt="VoltGo Charging Station"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </section>
  );
}
