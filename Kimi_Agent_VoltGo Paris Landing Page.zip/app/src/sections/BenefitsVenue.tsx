import { useRef, useLayoutEffect } from 'react';
import { Check, TrendingUp } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const benefits = [
  'Earn commission on every rental',
  'No maintenance, no staff time',
  'Small footprint—one outlet',
];

export function BenefitsVenue() {
  const sectionRef = useRef<HTMLElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const imageCardRef = useRef<HTMLDivElement>(null);
  const darkCardRef = useRef<HTMLDivElement>(null);
  const metricRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      // Label
      scrollTl.fromTo(
        labelRef.current,
        { y: -18, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0
      );

      // Left image card
      scrollTl.fromTo(
        imageCardRef.current,
        { x: '-60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Right dark card
      scrollTl.fromTo(
        darkCardRef.current,
        { x: '60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );

      // Metric
      scrollTl.fromTo(
        metricRef.current,
        { scale: 0.9, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.18
      );

      // SETTLE (30-70%): Hold

      // EXIT (70-100%)
      scrollTl.fromTo(
        imageCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-12vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        darkCardRef.current,
        { x: 0, opacity: 1 },
        { x: '12vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        [labelRef.current, metricRef.current],
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen bg-voltgo-cloud overflow-hidden z-[60]"
    >
      {/* Label */}
      <span
        ref={labelRef}
        className="absolute top-[10vh] left-1/2 -translate-x-1/2 font-mono text-xs tracking-[0.12em] uppercase text-voltgo-slate"
      >
        For Your Venue
      </span>

      {/* Cards Container */}
      <div className="absolute inset-0 flex items-center justify-center px-[6vw]">
        <div className="flex gap-[4vw] w-full max-w-6xl">
          {/* Left Image Card */}
          <div
            ref={imageCardRef}
            className="w-[42vw] h-[62vh] rounded-[28px] overflow-hidden card-shadow"
          >
            <img
              src="/venue_barista.jpg"
              alt="Barista at work"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Right Dark Card */}
          <div
            ref={darkCardRef}
            className="w-[42vw] h-[62vh] rounded-[28px] bg-voltgo-navy text-white p-8 lg:p-10 flex flex-col justify-between"
          >
            {/* Title */}
            <div>
              <h3
                className="font-display font-bold text-white mb-6"
                style={{ fontSize: 'clamp(1.75rem, 2.8vw, 2.5rem)', lineHeight: 1.1 }}
              >
                Turn power into profit
              </h3>

              {/* Benefits List */}
              <ul className="space-y-4">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-voltgo-green/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Check className="w-3.5 h-3.5 text-voltgo-green" />
                    </div>
                    <span className="text-white/80 leading-relaxed">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Metric */}
            <div ref={metricRef} className="animate-breathe">
              <div className="flex items-center gap-3">
                <TrendingUp className="w-6 h-6 text-voltgo-green" />
                <span className="font-mono text-sm text-white/60 uppercase tracking-wider">
                  Commission
                </span>
              </div>
              <p className="font-display font-bold text-5xl lg:text-6xl text-voltgo-green mt-2">
                10%
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
