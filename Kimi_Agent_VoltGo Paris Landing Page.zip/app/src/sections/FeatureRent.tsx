import { useRef, useLayoutEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function FeatureRent() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const pillRef = useRef<HTMLSpanElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      // Image from left
      scrollTl.fromTo(
        imageRef.current,
        { x: '-70vw', opacity: 0, scale: 0.98 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      // Pill
      scrollTl.fromTo(
        pillRef.current,
        { scale: 0.85, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0.08
      );

      // Headline
      scrollTl.fromTo(
        headlineRef.current,
        { y: 40, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      // Body + CTA
      scrollTl.fromTo(
        bodyRef.current,
        { y: 22, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.14
      );

      // SETTLE (30-70%): Hold

      // EXIT (70-100%)
      scrollTl.fromTo(
        imageRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        [pillRef.current, headlineRef.current, bodyRef.current],
        { x: 0, opacity: 1 },
        { x: '10vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen bg-voltgo-cloud overflow-hidden z-30"
    >
      {/* Left Image Card */}
      <div
        ref={imageRef}
        className="absolute left-[6vw] top-[14vh] w-[44vw] h-[72vh] rounded-[28px] overflow-hidden card-shadow"
      >
        <img
          src="/feature_rent.jpg"
          alt="Rent a Power Bank"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Right Text Block */}
      <div className="absolute left-[56vw] top-[20vh] w-[38vw] max-w-lg">
        {/* Pill */}
        <span
          ref={pillRef}
          className="inline-block bg-voltgo-green/10 text-voltgo-navy font-mono text-xs tracking-wider uppercase px-4 py-2 rounded-full mb-6"
        >
          €2/hour
        </span>

        {/* Headline */}
        <h2
          ref={headlineRef}
          className="font-display font-bold text-voltgo-navy mb-6"
          style={{ fontSize: 'clamp(2.25rem, 3.6vw, 3.25rem)', lineHeight: 1.05 }}
        >
          Rent a Power Bank
        </h2>

        {/* Body + CTA */}
        <div ref={bodyRef}>
          <p className="text-voltgo-slate text-lg leading-relaxed mb-6">
            Guests unlock a charger with a quick tap—no apps, no passwords.
            While they stay, their phone charges.
          </p>
          <a
            href="#pricing"
            className="inline-flex items-center text-voltgo-navy font-medium hover:text-voltgo-green transition-colors group"
          >
            See pricing details
            <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
          </a>
        </div>
      </div>
    </section>
  );
}
