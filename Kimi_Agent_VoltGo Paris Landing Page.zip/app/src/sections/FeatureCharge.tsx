import { useRef, useLayoutEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function FeatureCharge() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      // Image from right
      scrollTl.fromTo(
        imageRef.current,
        { x: '70vw', opacity: 0, scale: 0.98 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      // Content from left
      scrollTl.fromTo(
        contentRef.current,
        { x: '-18vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.08
      );

      // SETTLE (30-70%): Hold

      // EXIT (70-100%)
      scrollTl.fromTo(
        imageRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        contentRef.current,
        { x: 0, opacity: 1 },
        { x: '-10vw', opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full h-screen bg-voltgo-cloud overflow-hidden z-40"
    >
      {/* Left Text Block */}
      <div
        ref={contentRef}
        className="absolute left-[6vw] top-[20vh] w-[38vw] max-w-lg"
      >
        {/* Pill */}
        <span className="inline-block bg-voltgo-green/10 text-voltgo-navy font-mono text-xs tracking-wider uppercase px-4 py-2 rounded-full mb-6">
          Freedom
        </span>

        {/* Headline */}
        <h2
          className="font-display font-bold text-voltgo-navy mb-6"
          style={{ fontSize: 'clamp(2.25rem, 3.6vw, 3.25rem)', lineHeight: 1.05 }}
        >
          Charge Anywhere
        </h2>

        {/* Body */}
        <p className="text-voltgo-slate text-lg leading-relaxed mb-6">
          No need to sit near a wall. Guests can charge at the table, on the
          terrace, or on the move—then return when they're done.
        </p>
        <a
          href="#experience"
          className="inline-flex items-center text-voltgo-navy font-medium hover:text-voltgo-green transition-colors group"
        >
          Explore the experience
          <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
        </a>
      </div>

      {/* Right Image Card */}
      <div
        ref={imageRef}
        className="absolute right-[6vw] top-[14vh] w-[44vw] h-[72vh] rounded-[28px] overflow-hidden card-shadow"
      >
        <img
          src="/feature_charge.jpg"
          alt="Charge Anywhere"
          className="w-full h-full object-cover"
        />
      </div>
    </section>
  );
}
